module.exports = {
  images: {
    domains: [
      'cyld2018.speedgabia.com',
      'cyld20181.speedgabia.com',
      'cyld20182.speedgabia.com',
      'cyld20183.speedgabia.com',
      'cyld20184.speedgabia.com',
      'cyld20185.speedgabia.com',
      'cyld20186.speedgabia.com',
      'cyld20187.speedgabia.com',
      'cyld20188.speedgabia.com',
      'cyld20189.speedgabia.com',
      'localhost',
    ],
  },
  experimental: {
    scrollRestoration: true,
  },
};
